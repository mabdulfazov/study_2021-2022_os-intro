---
## Front matter
lang: ru-RU
title: Индивидуальный проект. Этап 5
author: Мансур А. о. Абдулфазов\inst{1,3}
        Группа НФИбд-01-21
date: 27 мая, 2021, Россия, Москва

## Formatting
toc: false
slide_level: 2
theme: metropolis
header-includes: 
 - \metroset{progressbar=frametitle,sectionpage=progressbar,numbering=fraction}
 - '\makeatletter'
 - '\beamer@ignorenonframefalse'
 - '\makeatother'
aspectratio: 43
section-titles: true
---


## Цель работы

Добавить с сайту все остальные элементы.

## Выполнение лабораторной работы

1. Сделал записи для персональных проектов.

![Результат выполнения первого задания](./images_prj05/1.png){ #fig:001 width=90% }

##

2. Сделал пост по прошедшей неделе.

![Результат выполнения второго задания](./images_prj05/2.png){ #fig:002 width=90% }

##

3. Добавил пост на тему языки научного программирования.

![Результат выполнения третьего задания](./images_prj05/3.png){ #fig:003 width=90% }


## Вывод

Добавил с сайту все остальные элементы.

